//
//  MLJMomentController.m
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "MLJMomentController.h"
#import "MLJMoentHeaderView.h"
#import "MLJMomentModel.h"
#import "MLJMomentCell.h"
static NSString *cellID = @"cell";
@interface MLJMomentController ()<UITableViewDataSource>

@end

@implementation MLJMomentController{
    NSMutableArray <MLJMomentModel *> *_momentList;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //加载数据
    [self loadData];
    //创建UI
    [self setupUI];
}
-(void)loadData{
    NSURL *url = [[NSBundle mainBundle]URLForResource:@"momentplist.plist" withExtension:nil];
    
    NSArray *array = [NSArray arrayWithContentsOfURL:url];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        MLJMomentModel *model = [MLJMomentModel momentWithDict:dict];
        
        [arrayM addObject:model];
    }
    _momentList = arrayM.copy;
}
-(void) setupUI{
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    tableView.dataSource = self;
    [tableView registerClass:[MLJMomentCell class] forCellReuseIdentifier:cellID];
    [self.view addSubview:tableView];
    
    MLJMoentHeaderView *headerView = [[MLJMoentHeaderView alloc]initWithFrame:CGRectMake(0, 0, 0, 220)];
    tableView.tableHeaderView = headerView;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _momentList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MLJMomentCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.model = _momentList[indexPath.row];
    return cell;
}
@end
