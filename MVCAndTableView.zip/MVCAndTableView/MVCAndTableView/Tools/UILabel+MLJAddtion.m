//
//  UILabel+MLJAddtion.m
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "UILabel+MLJAddtion.h"

@implementation UILabel (MLJAddtion)

+(instancetype)labelWithText:(NSString *)text fontSize:(CGFloat)fontsize color:(UIColor *)color{
    UILabel *lable = [[UILabel alloc]init];
    lable.text = text;
    lable.font = [UIFont systemFontOfSize:fontsize];
    lable.textColor = color;
    return lable;
}
@end
