//
//  MLJMoentHeaderView.m
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "MLJMoentHeaderView.h"
#import "UILabel+MLJAddtion.h"
#import "Masonry.h"
@implementation MLJMoentHeaderView
-(instancetype)initWithFrame:(CGRect)frame{
    if (self  = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}
-(void)setupUI{
    UILabel *sceneLab = [UILabel labelWithText:@"现场" fontSize:14 color:[UIColor redColor]];
    [self addSubview:sceneLab];
    
    UIImageView *image = [[UIImageView alloc]init];
    image.image = [UIImage imageNamed:@"安装完成"];
    [self addSubview:image];
    
    UILabel *momentLab = [UILabel labelWithText:@"朋友动态" fontSize:14 color:[UIColor blueColor]];
    [self addSubview:momentLab];
    
    [sceneLab mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.offset(20);
        make.left.offset(8);
    }];
    [image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sceneLab.mas_bottom).offset(8);
        make.left.equalTo(sceneLab);
        make.right.offset(-8);
    }];
    [momentLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(sceneLab);
        make.top.equalTo(image.mas_bottom).offset(8);
    }];
}
@end
