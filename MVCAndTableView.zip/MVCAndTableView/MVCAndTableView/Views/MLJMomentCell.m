//
//  MLJMomentCell.m
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "MLJMomentCell.h"
#import "Masonry.h"
#import "UILabel+MLJAddtion.h"
@interface MLJMomentCell()
@property(weak,nonatomic)UIImageView *iconImage;
@property (nonatomic,weak) UILabel *nameLabel;
@property (nonatomic,weak) UILabel *contentLabel;
@property (nonatomic,weak) UIImageView *pictureImage;
@property (nonatomic,weak) UILabel *timeLabel;
@end
@implementation MLJMomentCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupUI];
    }
    return self;
}
-(void)setupUI{
    //t头像
    UIImageView *iconImage = [[UIImageView alloc]init];
    [self.contentView addSubview:iconImage];
    _iconImage = iconImage;
    //用户名
    UILabel *nameLabel = [UILabel labelWithText:nil fontSize:14 color:[UIColor blackColor]];
    [self.contentView addSubview:nameLabel];
    _nameLabel = nameLabel;
    //内容
    UILabel *contentLabel = [UILabel labelWithText:nil fontSize:14 color:[UIColor blackColor]];
    contentLabel.numberOfLines = 0;
    [self.contentView addSubview:contentLabel];
    _contentLabel = contentLabel;
    //图片
    UIImageView *pictureImage = [[UIImageView alloc]init];
    [self.contentView addSubview:pictureImage];
    _pictureImage = pictureImage;
    //时间
    UILabel *timeLabel = [UILabel labelWithText:nil fontSize:14 color:[UIColor blackColor]];
    [self.contentView addSubview:timeLabel];
    _timeLabel = timeLabel;
    //删除
    UIButton *deleteBtn = [[UIButton alloc]init];
    [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [deleteBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    deleteBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.contentView addSubview:deleteBtn];
    //更多
    UIButton *moreBtn = [[UIButton alloc]init];
    [moreBtn setBackgroundImage:[UIImage imageNamed:@"more"] forState:UIControlStateNormal];
    [self.contentView addSubview:moreBtn];
    
    [iconImage setImage:[UIImage imageNamed:@"more"]];
    [iconImage mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.left.offset(8);
        //        make.top.offset(8);
        make.left.top.offset(8);
        make.width.height.offset(40);
    }];
    nameLabel.text = @"难上加难就";
    [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(iconImage);
        make.left.equalTo(iconImage.mas_right).offset(8);
    }];
    contentLabel.text = @"吗看市民卡美食卡吗看市民卡美食卡吗看市民卡美食卡吗看市民卡美食卡吗看市民卡美食卡吗看市民卡美食卡吗看市民卡美食卡美食卡吗看市民卡美食卡吗看市民美食卡吗看市民卡美食卡吗看市民美食卡吗看市民卡美食卡吗看市民";
    [contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(nameLabel);
        make.top.equalTo(nameLabel.mas_bottom).offset(8);
        make.right.equalTo(self).offset(-8);
    }];
    [pictureImage setImage:[UIImage imageNamed:@"预约成功"]];
    [pictureImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(nameLabel);
        make.top.equalTo(contentLabel.mas_bottom).offset(8);
        make.height.mas_lessThanOrEqualTo(150);
        //        make.width.offset(200);
    }];
    timeLabel.text = @"今天";
    [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(nameLabel);
        make.top.equalTo(pictureImage.mas_bottom).offset(8);
        
    }];
    
    [deleteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(timeLabel.mas_right).offset(8);
        make.baseline.equalTo(timeLabel);//  baseline - 控件对齐
    }];
    
    [moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-8);
        make.top.equalTo(deleteBtn);
        make.width.height.offset(20);
    }];
    
    [self.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
        make.bottom.mas_equalTo(moreBtn).offset(8);
        //        make.bottom.equalTo(moreBtn.mas_bottom).offset(8);
    }];
}
-(void)setModel:(MLJMomentModel *)model{
    _model = model;
    
    _iconImage.image = [UIImage imageNamed:model.icon];
    _nameLabel.text = model.name;
    _contentLabel.text = model.content;
    if (model.picture) {
        UIImage *image = [UIImage imageNamed:model.picture];

        //显示宽度/实际宽度 = 显示高度/实际高度
        CGFloat width = 150 / image.size.height * image.size.width;
        
        [_pictureImage mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(width);
        }];
        
        _pictureImage.image = image;

    }else{
        _pictureImage.image = nil;
        
        [_timeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_contentLabel.mas_bottom).offset(8);
        }];

    }
    _timeLabel.text = model.time;
}
@end
