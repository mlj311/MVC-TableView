//
//  MLJMomentCell.h
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLJMomentModel.h"
@interface MLJMomentCell : UITableViewCell
@property (strong,nonatomic) MLJMomentModel *model;
@end
