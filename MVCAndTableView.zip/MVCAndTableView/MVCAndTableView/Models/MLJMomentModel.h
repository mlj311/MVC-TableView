//
//  MLJMomentModel.h
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MLJMomentModel : NSObject
/**
 图标
 */
@property (copy,nonatomic) NSString *icon;

/**
 用户名称
 */
@property (copy,nonatomic) NSString *name;

/**
 发表时间
 */
@property (copy,nonatomic) NSString *time;

/**
 发表内容
 */
@property (copy,nonatomic) NSString *content;

/**
 发表图片
 */
@property (nonatomic,copy) NSString *picture;

-(instancetype)initWithDict:(NSDictionary *)dict;
+(instancetype)momentWithDict:(NSDictionary *)dict;
@end
