//
//  MLJMomentModel.m
//  MVCAndTableView
//
//  Created by 茅露军 on 2017/12/8.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "MLJMomentModel.h"

@implementation MLJMomentModel
-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+(instancetype)momentWithDict:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}
@end
